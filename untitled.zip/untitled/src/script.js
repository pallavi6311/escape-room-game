// Game 1: Find the Hidden Key
function searchDesk() {
    document.getElementById('game1-message').textContent = "You searched the desk but found nothing.";
}

function searchPlant() {
    document.getElementById('game1-message').textContent = "You found the key in the plant! Proceed to the next game.";
}

function searchPainting() {
    document.getElementById('game1-message').textContent = "You searched the painting but found nothing.";
}

// Game 2: Number Lock Puzzle
function checkCode() {
    const code = document.getElementById('code-input').value;
    if (code === "123") {
        document.getElementById('game2-message').textContent = "You unlocked the box! Proceed to the next game.";
    } else {
        document.getElementById('game2-message').textContent = "Incorrect code. Try again.";
    }
}

// Game 3: Riddle Challenge
function checkRiddle() {
    const answer = document.getElementById('riddle-input').value.toLowerCase();
    if (answer === "echo") {
        document.getElementById('game3-message').textContent = "Correct! You solved the riddle and escaped the room!";
        document.getElementById('final-message').textContent = "Congratulations! You've escaped the room!";
    } else {
        document.getElementById('game3-message').textContent = "Incorrect answer. Try again.";
    }
}